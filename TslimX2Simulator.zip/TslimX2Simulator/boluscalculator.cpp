#include "boluscalculator.h"

BolusCalculator::BolusCalculator()
{

}
