#ifndef BOLUSCALCULATOR_H
#define BOLUSCALCULATOR_H


class BolusCalculator
{
public:
    BolusCalculator();
};

#endif // BOLUSCALCULATOR_H
