#include "historylog.h"

HistoryLog::HistoryLog()
{

}
