#ifndef HISTORYLOG_H
#define HISTORYLOG_H


class HistoryLog
{
public:
    HistoryLog();
};

#endif // HISTORYLOG_H
