#include "insulindelivery.h"

InsulinDelivery::InsulinDelivery()
{

}
