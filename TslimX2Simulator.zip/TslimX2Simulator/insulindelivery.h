#ifndef INSULINDELIVERY_H
#define INSULINDELIVERY_H


class InsulinDelivery
{
public:
    InsulinDelivery();
};

#endif // INSULINDELIVERY_H
