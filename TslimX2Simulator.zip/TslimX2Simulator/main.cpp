#include "mainwindow.h"
#include "pinlockview.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    PinLockView pinLockView;
    pinLockView.show();
    QObject::connect(&pinLockView, &PinLockView::unlocked, [&]() {
        pinLockView.close();  // Close the PIN lock screen
        w.show();     // Show the home screen
    });
    return a.exec();
}
