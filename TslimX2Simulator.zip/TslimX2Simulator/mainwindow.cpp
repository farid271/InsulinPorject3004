#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "pinlockview.h"
#include "profilenameinput.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Create and add the ProfileNameInput widget to the layout
    ProfileNameInput *profileInput = new ProfileNameInput;
    ui->pageProfileInput->layout()->addWidget(profileInput);  // This assumes the layout is set

    // Connect the nameConfirmed signal to the slot
    connect(profileInput, &ProfileNameInput::nameConfirmed, this, [=](QString &name){
        ui->profileList->addItem(name);  // Add name to the list widget
        ui->stackedWidget->setCurrentWidget(ui->profilePage);  // Go back to profile page
    });

    // Show the ProfileNameInput page when the 'Add Profile' button is clicked
    connect(ui->addProfile, &QPushButton::clicked, this, [=]() {
        ui->stackedWidget->setCurrentWidget(ui->pageProfileInput);  // Go to the profile input page
    });

    connect(ui->bolusButton, &QPushButton::clicked, this, [=]() {
        ui->stackedWidget->setCurrentIndex(1); // Go to bolus page
    });

    connect(ui->otherButton, &QPushButton::clicked, this, [=]() {
        ui->stackedWidget->setCurrentIndex(2); // Go to options page
    });

    connect(ui->backHomeButton, &QPushButton::clicked, this, [=]() {
        ui->stackedWidget->setCurrentIndex(0); // Go back to home
    });

    connect(ui->backHomeTwoButton, &QPushButton::clicked, this, [=]() {
        ui->stackedWidget->setCurrentIndex(0); // Go back to home
    });

    connect(ui->backHomeThreeButton, &QPushButton::clicked, this, [=]() {
        ui->stackedWidget->setCurrentIndex(0); // Go back to home
    });
    
    connect(ui->downOneButton, &QPushButton::clicked, this, [=]() {
        ui->stackedWidget->setCurrentIndex(3); // Go to options second page
    });

    connect(ui->upButton, &QPushButton::clicked, this, [=]() {
        ui->stackedWidget->setCurrentIndex(2); // Go to options second page
    });

    connect(ui->backHomeProfile, &QPushButton::clicked, this, [=]() {
        ui->stackedWidget->setCurrentIndex(0); // Go to home
    });

    connect(ui->myPumpButton, &QPushButton::clicked, this, [=]() {
        ui->stackedWidget->setCurrentIndex(4); // Go to home
    });
    

}

MainWindow::~MainWindow()
{
    delete ui;
}















