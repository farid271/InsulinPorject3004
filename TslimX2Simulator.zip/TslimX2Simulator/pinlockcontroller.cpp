#include "pinlockcontroller.h"

PinLockController::PinLockController() {
    currentPin = "1234";
}

PinLockController& PinLockController::instance() {
    static PinLockController instance;
    return instance;
}

bool PinLockController::verifyPin(const QString& input) {
    return input == currentPin;
}

QString PinLockController::getCurrentPin() const {
    return currentPin;
}
