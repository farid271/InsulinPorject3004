#ifndef PINLOCKCONTROLLER_H
#define PINLOCKCONTROLLER_H

#include <QString>

class PinLockController {
public:
    static PinLockController& instance();

    bool verifyPin(const QString& input);
    QString getCurrentPin() const;

private:
    PinLockController();
    QString currentPin;
};

#endif
