#include "pinlockview.h"
#include "pinlockcontroller.h"
#include <QGridLayout>
#include <QPushButton>
#include <QLabel>

PinLockView::PinLockView(QWidget *parent) : QWidget(parent) {
    setWindowFlags(Qt::Dialog | Qt::FramelessWindowHint);
    setWindowModality(Qt::ApplicationModal);
    setFixedSize(300, 400);

    QGridLayout *layout = new QGridLayout(this);

    statusLabel = new QLabel("Enter PIN:", this);
    layout->addWidget(statusLabel, 0, 0, 1, 3);

    // Set background color and label text color
    setStyleSheet("background-color: black; color: white;");

    // Create numeric keypad (buttons 0-9)
    QStringList buttonLabels = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0"};
    int row = 1, col = 0;
    for (const QString &label : buttonLabels) {
        QPushButton *button = new QPushButton(label, this);
        connect(button, &QPushButton::clicked, this, &PinLockView::buttonClicked);
        button->setStyleSheet("background-color: rgb(43, 49, 45); color: white; font-size: 18px; font-weight: bold;");
        layout->addWidget(button, row, col);
        col++;
        if (col == 3) {
            col = 0;
            row++;
        }
    }

    // Create Clear and Enter buttons
    QPushButton *clearButton = new QPushButton("C", this);
    connect(clearButton, &QPushButton::clicked, this, [this]() { enteredPin.clear(); updatePinDisplay(); });
    clearButton->setStyleSheet("background-color: rgb(43, 49, 45); color: white; font-size: 18px; font-weight: bold;");
    layout->addWidget(clearButton, row, 0);

    QPushButton *enterButton = new QPushButton("OK", this);
    connect(enterButton, &QPushButton::clicked, this, &PinLockView::tryUnlock);
    enterButton->setStyleSheet("background-color: blue; color: white; font-size: 18px; font-weight: bold;");
    layout->addWidget(enterButton, row, 1, 1, 2);

    this->setLayout(layout);
}


void PinLockView::buttonClicked() {
    QPushButton *button = qobject_cast<QPushButton*>(sender());
    if (button) {
        enteredPin += button->text();
        updatePinDisplay();
    }
}

void PinLockView::updatePinDisplay() {
    statusLabel->setText("Enter PIN: " + enteredPin);
}

void PinLockView::tryUnlock() {
    if (PinLockController::instance().verifyPin(enteredPin)) {
        emit unlocked();
        this->close();
    } else {
        statusLabel->setText("Incorrect PIN. Try again.");
    }
}


