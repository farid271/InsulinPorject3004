#ifndef PINLOCKVIEW_H
#define PINLOCKVIEW_H

#include <QWidget>
#include <QPushButton>
#include <QLabel>
#include <QGridLayout>

class PinLockView : public QWidget {
    Q_OBJECT

public:
    explicit PinLockView(QWidget *parent = nullptr);

signals:
    void unlocked();

private slots:
    void buttonClicked();
    void tryUnlock();

private:
    void updatePinDisplay();

    QLabel *statusLabel;
    QString enteredPin;
};

#endif // PINLOCKVIEW_H

