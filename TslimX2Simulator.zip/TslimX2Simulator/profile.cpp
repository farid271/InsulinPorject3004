#include "profile.h"

Profile::Profile() :
    m_basalRate(0.0),
    m_carbRatio(0.0),
    m_correctionFactor(0.0),
    m_targetGlucose(0)
{}

Profile::Profile(const QString &name, double basalRate, double carbRatio,
                 double correctionFactor, int targetGlucose) :
    m_name(name),
    m_basalRate(basalRate),
    m_carbRatio(carbRatio),
    m_correctionFactor(correctionFactor),
    m_targetGlucose(targetGlucose)
{}

// Getters
QString Profile::getName() const { return m_name; }
double Profile::getBasalRate() const { return m_basalRate; }
double Profile::getCarbRatio() const { return m_carbRatio; }
double Profile::getCorrectionFactor() const { return m_correctionFactor; }
int Profile::getTargetGlucose() const { return m_targetGlucose; }

// Setters
void Profile::setName(const QString &name) { m_name = name; }
void Profile::setBasalRate(double rate) { m_basalRate = rate; }
void Profile::setCarbRatio(double ratio) { m_carbRatio = ratio; }
void Profile::setCorrectionFactor(double factor) { m_correctionFactor = factor; }
void Profile::setTargetGlucose(int target) { m_targetGlucose = target; }


