#ifndef PROFILE_H
#define PROFILE_H

#include <QString>

class Profile {
public:
    Profile();
    Profile(const QString &name,
            double basalRate,
            double carbRatio,
            double correctionFactor,
            int targetGlucose);

    // Getters
    QString getName() const;
    double getBasalRate() const;
    double getCarbRatio() const;
    double getCorrectionFactor() const;
    int getTargetGlucose() const;

    // Setters
    void setName(const QString &name);
    void setBasalRate(double rate);
    void setCarbRatio(double ratio);
    void setCorrectionFactor(double factor);
    void setTargetGlucose(int target);

private:
    QString m_name;
    double m_basalRate;
    double m_carbRatio;
    double m_correctionFactor;
    int m_targetGlucose;
};

#endif // PROFILE_H



