#include "profilemanager.h"

ProfileManager::ProfileManager() {}

void ProfileManager::addProfile(const Profile &profile) {
    m_profiles.append(profile);
}

QVector<Profile> ProfileManager::getProfiles() const {
    return m_profiles;
}

bool ProfileManager::updateProfile(const QString &name, const Profile &updatedProfile) {
    for (int i = 0; i < m_profiles.size(); ++i) {
        if (m_profiles[i].getName() == name) {
            m_profiles[i] = updatedProfile;
            return true;
        }
    }
    return false;
}

bool ProfileManager::deleteProfile(const QString &name) {
    for (int i = 0; i < m_profiles.size(); ++i) {
        if (m_profiles[i].getName() == name) {
            m_profiles.remove(i);
            return true;
        }
    }
    return false;
}

Profile* ProfileManager::getProfile(const QString &name) {
    for (int i = 0; i < m_profiles.size(); ++i) {
        if (m_profiles[i].getName() == name) {
            return &m_profiles[i];
        }
    }
    return nullptr;
}

