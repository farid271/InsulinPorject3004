#ifndef PROFILEMANAGER_H
#define PROFILEMANAGER_H

#include "profile.h"
#include <QVector>
#include <QString>

class ProfileManager {
public:
    ProfileManager();

    void addProfile(const Profile &profile);
    QVector<Profile> getProfiles() const;
    bool updateProfile(const QString &name, const Profile &updatedProfile);
    bool deleteProfile(const QString &name);
    Profile* getProfile(const QString &name);

private:
    QVector<Profile> m_profiles;
};

#endif // PROFILEMANAGER_H

