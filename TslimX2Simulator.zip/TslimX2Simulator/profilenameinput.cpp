// ProfileNameInput.cpp
#include "profilenameinput.h"
#include <QVBoxLayout>
#include <QGridLayout>
#include <QFont>

ProfileNameInput::ProfileNameInput(QWidget *parent) : QWidget(parent), pressCount(0) {
    keyMap["ABC"] = "ABC";
    keyMap["DEF"] = "DEF";
    keyMap["GHI"] = "GHI";
    keyMap["JKL"] = "JKL";
    keyMap["MNO"] = "MNO";
    keyMap["PQR"] = "PQR";
    keyMap["STU"] = "STU";
    keyMap["VWX"] = "VWX";
    keyMap["YZ"] = "YZ_";
    keyMap["0"] = " ";

    pressTimer = new QTimer(this);
    pressTimer->setInterval(1000);
    pressTimer->setSingleShot(true);
    connect(pressTimer, &QTimer::timeout, this, [this]() {
        currentText += keyMap[lastKey][pressCount % keyMap[lastKey].length()];
        display->setText(currentText);
        lastKey.clear();
        pressCount = 0;
    });

    createLayout();
}

void ProfileNameInput::createLayout() {
    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    display = new QLineEdit(this);
    display->setReadOnly(true);
    display->setStyleSheet("font-size: 24px; padding: 10px;");
    mainLayout->addWidget(display);

    QGridLayout *gridLayout = new QGridLayout();
    QStringList keys = {"ABC", "DEF", "GHI", "JKL", "MNO", "PQR", "STU", "VWX", "YZ", "0"};

    for (int i = 0; i < keys.size(); ++i) {
        QPushButton *button = new QPushButton(keys[i], this);
        button->setFixedSize(80, 80);
        button->setStyleSheet("background-color: rgb(43,49,45); color: white; font-size: 18px;");
        QFont font = button->font();
        font.setBold(true);
        button->setFont(font);
        connect(button, &QPushButton::clicked, this, [this, key = keys[i]]() { handleKeyPress(key); });
        gridLayout->addWidget(button, i / 3, i % 3);
    }

    mainLayout->addLayout(gridLayout);

    QPushButton *confirmButton = new QPushButton("Confirm", this);
    confirmButton->setStyleSheet("background-color: blue; color: white; font-size: 20px; padding: 10px;");
    connect(confirmButton, &QPushButton::clicked, this, &ProfileNameInput::confirmName);
    mainLayout->addWidget(confirmButton);
    setLayout(mainLayout);
}

void ProfileNameInput::handleKeyPress(const QString &key) {
    if (lastKey == key) {
        pressCount++;
    } else {
        if (!lastKey.isEmpty()) {
            currentText += keyMap[lastKey][pressCount % keyMap[lastKey].length()];
        }
        lastKey = key;
        pressCount = 0;
    }
    pressTimer->start();
    display->setText(currentText + keyMap[key][pressCount % keyMap[key].length()]);
}

void ProfileNameInput::confirmName() {
    if (!lastKey.isEmpty()) {
        currentText += keyMap[lastKey][pressCount % keyMap[lastKey].length()];
    }
    emit nameConfirmed(currentText);
    currentText.clear();
    lastKey.clear();
    pressCount = 0;
    display->clear();
}

