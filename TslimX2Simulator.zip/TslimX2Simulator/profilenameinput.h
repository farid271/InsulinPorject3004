// ProfileNameInput.h
#ifndef PROFILENAMEINPUT_H
#define PROFILENAMEINPUT_H

#include <QWidget>
#include <QPushButton>
#include <QTimer>
#include <QLineEdit>
#include <QMap>

class ProfileNameInput : public QWidget
{
    Q_OBJECT

public:
    explicit ProfileNameInput(QWidget *parent = nullptr);

signals:
    void nameConfirmed(QString &name);

private slots:
    void handleKeyPress(const QString &key);
    void confirmName();

private:
    void createLayout();
    void cycleCharacter(const QString &key);

    QLineEdit *display;
    QString currentText;
    QMap<QString, QString> keyMap;
    QString lastKey;
    int pressCount;
    QTimer *pressTimer;
};

#endif // PROFILENAMEINPUT_H

